package com.asi.bookmyshow;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MovieService {
    @Autowired
    private MovieRepository movieRepository;
    @Autowired
    private ShowtimeRepository showtimeRepository;
    @Autowired
    private BookingRepository bookingRepository;

    // Existing methods for fetching movies, showtimes, and booking tickets

    public void saveMovie(Movie movie) {
        movieRepository.save(movie);
    }

    public void saveShowtime(Showtime showtime) {
        showtimeRepository.save(showtime);
    }

    public void saveBooking(Booking booking) {
        bookingRepository.save(booking);
    }

	public List<Movie> getAllMovies() {
		return movieRepository.findAll();
	}

	public List<Showtime> getShowtimesForMovie(Long movieId) {
		return showtimeRepository.findByMovieId(movieId);
	}

	public boolean bookTicket(BookingRequest bookingRequest) {
	    if (isValidBooking(bookingRequest)) {
	        return true;
	    } else {
	        return false;
	    }
	}

	private boolean isValidBooking(BookingRequest bookingRequest) {
	    return true; 
	}

	

    public Showtime getShowtimeById(Long showtimeId) {
        for (Showtime showtime : showtimes) {
            if (showtime.getId().equals(showtimeId)) {
                return showtime;
            }
        }
        // If no matching showtime is found, return null
        return null;
    }

    
  
}
