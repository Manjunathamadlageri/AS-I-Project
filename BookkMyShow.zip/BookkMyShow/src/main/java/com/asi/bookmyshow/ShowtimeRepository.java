package com.asi.bookmyshow;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ShowtimeRepository extends JpaRepository<Showtime, Long> {
	  List<Showtime> findByMovieId(Long movieId);
}
