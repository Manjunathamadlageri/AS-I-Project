package com.asi.bookmyshow;

import java.util.ArrayList;
import java.util.List;

public class ShowtimeManager {
    private List<Showtime> showtimes;

    public ShowtimeManager(List<Showtime> initialShowtimes) {
        this.showtimes = new ArrayList<>(initialShowtimes);
    }

    public Showtime getShowtimeById(Long showtimeId) {
        for (Showtime showtime : showtimes) {
            if (showtime.getId().equals(showtimeId)) {
                return showtime;
            }
        }
        return null;
    }
    public void addShowtime(Showtime newShowtime) {
        showtimes.add(newShowtime);
    }
}


