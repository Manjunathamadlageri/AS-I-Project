package com.asi.bookmyshow;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class BookingRequest {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long showtimeId;
    private String customerName;
    public BookingRequest(Long showtimeId, String customerName) {
        this.showtimeId = showtimeId;
        this.customerName = customerName;
    }

    public Long getShowtimeId() {
        return showtimeId;
    }

    public String getCustomerName() {
        return customerName;
    }

}
