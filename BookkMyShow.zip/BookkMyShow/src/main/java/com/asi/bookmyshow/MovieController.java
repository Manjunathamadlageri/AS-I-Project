package com.asi.bookmyshow;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/movies")
public class MovieController {
    @Autowired
    private MovieService movieService;
    @Autowired
    private MovieRepository movieRepository;

    @GetMapping
    public List<Movie> getAllMovies() {
        return movieService.getAllMovies();
    }
    
    @PostMapping("/add")
    public ResponseEntity<Movie> postMovie(@RequestBody Movie movie) {
        Movie savedMovie = movieRepository.save(movie);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedMovie);
    }

    @GetMapping("/{movieId}/showtimes")
    public List<Showtime> getShowtimesForMovie(@PathVariable Long movieId) {
        return movieService.getShowtimesForMovie(movieId);
    }

//    @PostMapping("/bookTicket")
//    public ResponseEntity<String> bookTicket(@RequestBody BookingRequest bookingRequest) {
//        boolean isBookingSuccessful = movieService.bookTicket(bookingRequest);
//        if (isBookingSuccessful) {
//            return ResponseEntity.ok("Ticket booked successfully!");
//        } else {
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Booking failed. No available seats.");
//        }
//    }
}
