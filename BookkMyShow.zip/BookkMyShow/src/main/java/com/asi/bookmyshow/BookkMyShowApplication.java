package com.asi.bookmyshow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookkMyShowApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookkMyShowApplication.class, args);
	}

}
