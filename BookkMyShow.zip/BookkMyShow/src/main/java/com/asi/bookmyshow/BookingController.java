package com.asi.bookmyshow;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/movies")
public class BookingController {
    @Autowired
    private MovieService movieService;

    @PostMapping("/bookTicket")
    public ResponseEntity<String> bookTicket(@RequestBody BookingRequest bookingRequest) {
        Long showtimeId = bookingRequest.getShowtimeId();
        String customerName = bookingRequest.getCustomerName();

        if (showtimeId != null && customerName != null && !customerName.isEmpty()) {
            Showtime showtime = movieService.getShowtimeById(showtimeId);
            if (showtime != null && showtime.getAvailableSeats() > 0) {
                Booking booking = new Booking();
                booking.setBookingTime(LocalDateTime.now());
                booking.setCustomerName(customerName);
                booking.setShowtime(showtime);
                movieService.saveBooking(booking);

                showtime.setAvailableSeats(showtime.getAvailableSeats() - 1);
                movieService.saveShowtime(showtime);

                return ResponseEntity.ok("Ticket booked successfully!");
            } else {
                return ResponseEntity.badRequest().body("Booking failed. No available seats.");
            }
        } else {
            return ResponseEntity.badRequest().body("Invalid input. Please provide showtimeId and customerName.");
        }
    }
}
