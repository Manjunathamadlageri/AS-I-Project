package com.asi.bookmyshow;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Booking {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private LocalDateTime bookingTime;
    private String customerName;
    @ManyToOne
    @JoinColumn(name = "showtime_id", nullable = false)
    private Showtime showtime;
    public Booking() {
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public void setShowtime(Showtime showtime) {
        this.showtime = showtime;
    }

    public void setBookingTime(LocalDateTime bookingTime) {
        this.bookingTime = bookingTime;
    }

    public String getCustomerName() {
        return customerName;
    }

    public Showtime getShowtime() {
        return showtime;
    }

    public LocalDateTime getBookingTime() {
        return bookingTime;
    }
}
