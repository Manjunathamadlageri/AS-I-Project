package com.asi.bookmyshow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookkMyShowApplicationTests {

	@Test
	void contextLoads() {
	}

}
